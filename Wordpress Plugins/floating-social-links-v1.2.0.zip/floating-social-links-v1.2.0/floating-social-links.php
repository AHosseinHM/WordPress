<?php
/**
 * Plugin Name: دکمه شناور شبکه‌های اجتماعی 
 * Description: نمایش دکمه شناور و لینک شبکه‌های اجتماعی با تنظیمات قابل ویرایش.
 * Version: 1.2.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: امیرحسین حسینمردی
 * Author URI: https://www.linkedin.com/in/amirhossein-hosseinmardi/
 * Text Domain: floating-social-links
 */
if (!defined('ABSPATH')) { exit; }

final class FSL_Floating_Social_Links {
    const OPTION = 'fsl_settings';
    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'register']);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_action('wp_footer', [$this, 'render']);
    }
    private function settings() {
        return wp_parse_args(get_option(self::OPTION, []), [
            'enabled' => 1, 'label' => 'ارتباط با ما', 'color' => '#2563eb',
            'position' => 'right', 'bottom' => 24, 'links' => [],
        ]);
    }
    private function icons() {
        return ['none' => 'بدون آیکون', 'instagram' => '📷 اینستاگرام', 'telegram' => '✈ تلگرام', 'whatsapp' => '💬 واتساپ', 'phone' => '☎ تلفن', 'email' => '✉ ایمیل', 'youtube' => '▶ یوتیوب', 'website' => '🌐 وب‌سایت', 'linkedin' => '💼 لینکدین', 'heart' => '♥ قلب'];
    }
    private function icon_options($selected = 'none') {
        foreach ($this->icons() as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($selected, $value, false) . '>' . esc_html($label) . '</option>';
        }
    }
    private function icon($key) {
        $icons = ['instagram' => '📷', 'telegram' => '✈', 'whatsapp' => '💬', 'phone' => '☎', 'email' => '✉', 'youtube' => '▶', 'website' => '🌐', 'linkedin' => '💼', 'heart' => '♥'];
        return $icons[$key] ?? '';
    }
    public function menu() {
        add_options_page('شبکه‌های اجتماعی شناور', 'دکمه شبکه‌های اجتماعی', 'manage_options', 'floating-social-links', [$this, 'page']);
    }
    public function register() {
        register_setting('fsl_group', self::OPTION, ['type' => 'array', 'sanitize_callback' => [$this, 'sanitize']]);
    }
    public function sanitize($input) {
        $input = is_array($input) ? $input : [];
        $output = [
            'enabled' => empty($input['enabled']) ? 0 : 1,
            'label' => sanitize_text_field($input['label'] ?? '') ?: 'ارتباط با ما',
            'color' => sanitize_hex_color($input['color'] ?? '') ?: '#2563eb',
            'position' => ($input['position'] ?? '') === 'left' ? 'left' : 'right',
            'bottom' => min(300, max(0, absint($input['bottom'] ?? 24))),
            'links' => [],
        ];
        $rows = isset($input['links']) && is_array($input['links']) ? $input['links'] : [];
        foreach (array_slice($rows, 0, 50) as $row) {
            if (!is_array($row)) { continue; }
            $name = sanitize_text_field($row['name'] ?? '');
            $url = esc_url_raw($row['url'] ?? '', ['https', 'http', 'mailto', 'tel']);
            if ($name !== '' && $url !== '') {
                $output['links'][] = ['name' => $name, 'url' => $url, 'icon_image' => esc_url_raw($row['icon_image'] ?? '', ['https', 'http']), 'icon' => isset($this->icons()[$row['icon'] ?? 'none']) ? ($row['icon'] ?? 'none') : 'none'];
            }
        }
        return $output;
    }
    public function page() {
        if (!current_user_can('manage_options')) { return; }
        wp_enqueue_media();
        $s = $this->settings();
        ?>
        <div class="wrap" dir="rtl">
            <h1>دکمه شناور شبکه‌های اجتماعی</h1>
            <p>سازنده: <a href="https://www.linkedin.com/in/amirhossein-hosseinmardi/" target="_blank" rel="noopener noreferrer">امیرحسین حسینمردی</a></p>
            <?php settings_errors(); ?>
            <form action="options.php" method="post">
                <?php settings_fields('fsl_group'); ?>
                <table class="form-table" role="presentation">
                    <tr><th>نمایش دکمه</th><td><label><input type="checkbox" name="fsl_settings[enabled]" value="1" <?php checked($s['enabled'], 1); ?>> فعال باشد</label></td></tr>
                    <tr><th><label for="fsl-label">متن دکمه</label></th><td><input id="fsl-label" class="regular-text" name="fsl_settings[label]" value="<?php echo esc_attr($s['label']); ?>" required></td></tr>
                    <tr><th><label for="fsl-color">رنگ دکمه</label></th><td><input id="fsl-color" type="color" name="fsl_settings[color]" value="<?php echo esc_attr($s['color']); ?>"></td></tr>
                    <tr><th><label for="fsl-position">محل نمایش</label></th><td><select id="fsl-position" name="fsl_settings[position]"><option value="right" <?php selected($s['position'], 'right'); ?>>پایین راست</option><option value="left" <?php selected($s['position'], 'left'); ?>>پایین چپ</option></select></td></tr>
                    <tr><th><label for="fsl-bottom">فاصله از پایین (پیکسل)</label></th><td><input id="fsl-bottom" type="number" min="0" max="300" name="fsl_settings[bottom]" value="<?php echo esc_attr($s['bottom']); ?>"></td></tr>
                </table>
                <h2>شبکه‌ها و راه‌های ارتباطی</h2>
                <p>نام و لینک کامل را وارد کنید؛ مثلاً اینستاگرام، تلگرام، واتساپ یا هر لینک دلخواه. ترتیب نمایش همان ترتیب ردیف‌هاست.</p>
                <p>تصویر دلخواه را از رسانه انتخاب یا آدرس آن را وارد کنید. تصویر بر آیکون نمادین اولویت دارد؛ با حذف تصویر، آیکون نمادین نمایش داده می‌شود. پیشنهاد: تصویر مربعی PNG یا WebP با پس‌زمینه شفاف.</p>
                <table class="widefat striped"><thead><tr><th>آیکون</th><th>نام شبکه</th><th>لینک</th><th>حذف</th></tr></thead><tbody id="fsl-rows">
                <?php foreach ($s['links'] as $i => $link) : ?>
                    <tr><td><select aria-label="آیکون شبکه" name="fsl_settings[links][<?php echo absint($i); ?>][icon]"><?php $this->icon_options($link['icon'] ?? 'none'); ?></select><p><input class="fsl-image-url" aria-label="آدرس تصویر آیکون" dir="ltr" type="url" name="fsl_settings[links][<?php echo absint($i); ?>][icon_image]" value="<?php echo esc_url($link['icon_image'] ?? ''); ?>" placeholder="https://…"><button type="button" class="button fsl-pick-image">انتخاب تصویر</button><button type="button" class="button fsl-clear-image">حذف تصویر</button></p></td><td><input aria-label="نام شبکه" style="width:100%" name="fsl_settings[links][<?php echo absint($i); ?>][name]" value="<?php echo esc_attr($link['name']); ?>" required></td><td><input aria-label="لینک شبکه" dir="ltr" style="width:100%" name="fsl_settings[links][<?php echo absint($i); ?>][url]" value="<?php echo esc_attr($link['url']); ?>" placeholder="https://…" required></td><td><button type="button" class="button fsl-remove">حذف</button></td></tr>
                <?php endforeach; ?>
                </tbody></table>
                <p><button id="fsl-add" type="button" class="button">افزودن شبکه</button></p>
                <?php submit_button('ذخیره تنظیمات'); ?>
            </form>
            <p>اگر هیچ لینکی اضافه نشده باشد، دکمه نمایش داده نمی‌شود. پس از ذخیره، در صورت استفاده از افزونه کش، کش سایت را پاک کنید.</p>
        </div>
        <template id="fsl-icon-options"><?php $this->icon_options(); ?></template>
        <script>
        (function () {
            const rows = document.getElementById('fsl-rows');
            let index = <?php echo count($s['links']); ?>;
            document.getElementById('fsl-add').addEventListener('click', function () {
                if (rows.children.length >= 50) return;
                const tr = document.createElement('tr');
                tr.innerHTML = '<td><input aria-label="نام شبکه" style="width:100%" name="fsl_settings[links][' + index + '][name]" required></td><td><input aria-label="لینک شبکه" dir="ltr" style="width:100%" name="fsl_settings[links][' + index + '][url]" placeholder="https://…" required></td><td><button type="button" class="button fsl-remove">حذف</button></td>';
                const iconCell = document.createElement('td');
                const iconSelect = document.createElement('select');
                iconSelect.name = 'fsl_settings[links][' + index + '][icon]';
                iconSelect.setAttribute('aria-label', 'آیکون شبکه');
                iconSelect.appendChild(document.getElementById('fsl-icon-options').content.cloneNode(true));
                iconCell.appendChild(iconSelect);
                const imageControls = document.createElement('p');
                imageControls.innerHTML = '<input class="fsl-image-url" aria-label="آدرس تصویر آیکون" dir="ltr" type="url" name="fsl_settings[links][' + index + '][icon_image]" placeholder="https://…"><button type="button" class="button fsl-pick-image">انتخاب تصویر</button><button type="button" class="button fsl-clear-image">حذف تصویر</button>';
                iconCell.appendChild(imageControls);
                tr.prepend(iconCell);
                index++;
                rows.appendChild(tr);
                tr.querySelector('input').focus();
            });
            rows.addEventListener('click', function (event) {
                if (event.target.classList.contains('fsl-remove')) event.target.closest('tr').remove();
                if (event.target.classList.contains('fsl-clear-image')) {
                    event.target.closest('td').querySelector('.fsl-image-url').value = '';
                }
                if (event.target.classList.contains('fsl-pick-image')) {
                    const input = event.target.closest('td').querySelector('.fsl-image-url');
                    const frame = wp.media({title: 'انتخاب آیکون شبکه', button: {text: 'استفاده از این تصویر'}, library: {type: 'image'}, multiple: false});
                    frame.on('select', function () {
                        const image = frame.state().get('selection').first().toJSON();
                        input.value = image.sizes && image.sizes.thumbnail ? image.sizes.thumbnail.url : image.url;
                    });
                    frame.open();
                }
            });
        })();
        </script>
        <?php
    }
    public function assets() {
        $s = $this->settings();
        if (empty($s['enabled']) || empty($s['links'])) { return; }
        wp_enqueue_style('fsl-widget', plugins_url('assets/widget.css', __FILE__), [], '1.2.0');
        wp_enqueue_script('fsl-widget', plugins_url('assets/widget.js', __FILE__), [], '1.2.0', true);
    }
    public function render() {
        $s = $this->settings();
        if (empty($s['enabled']) || empty($s['links'])) { return; }
        ?>
        <div id="fsl-widget" class="fsl-widget fsl-<?php echo esc_attr($s['position']); ?>" dir="rtl" style="--fsl-color:<?php echo esc_attr($s['color']); ?>;--fsl-bottom:<?php echo absint($s['bottom']); ?>px">
            <nav id="fsl-panel" class="fsl-panel" aria-label="شبکه‌های اجتماعی" hidden>
                <?php foreach ($s['links'] as $link) : ?>
                    <a href="<?php echo esc_url($link['url'], ['https', 'http', 'mailto', 'tel']); ?>" target="_blank" rel="noopener noreferrer"><span class="fsl-link-label"><span class="fsl-icon" aria-hidden="true"><?php if (!empty($link['icon_image'])) : ?><img class="fsl-custom-icon" src="<?php echo esc_url($link['icon_image'], ['https', 'http']); ?>" alt="" width="24" height="24"><?php else : ?><?php echo esc_html($this->icon($link['icon'] ?? 'none')); ?><?php endif; ?></span><span><?php echo esc_html($link['name']); ?></span></span><span aria-hidden="true">↗</span><span class="fsl-sr"> (باز شدن در پنجره جدید)</span></a>
                <?php endforeach; ?>
            </nav>
            <button type="button" id="fsl-toggle" class="fsl-toggle" aria-controls="fsl-panel" aria-expanded="false">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5Z"/></svg>
                <span><?php echo esc_html($s['label']); ?></span>
            </button>
        </div>
        <?php
    }
}
new FSL_Floating_Social_Links();

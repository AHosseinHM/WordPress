(() => {
    'use strict';
    const root = document.getElementById('fsl-widget');
    if (!root) return;
    const button = root.querySelector('#fsl-toggle');
    const panel = root.querySelector('#fsl-panel');
    let timer;
    let frame;
    const setOpen = (open) => {
        clearTimeout(timer);
        cancelAnimationFrame(frame);
        button.setAttribute('aria-expanded', String(open));
        panel.inert = !open;
        panel.setAttribute('aria-hidden', String(!open));
        if (open) {
            panel.hidden = false;
            void panel.offsetHeight;
            frame = requestAnimationFrame(() => root.classList.add('fsl-open'));
        } else {
            root.classList.remove('fsl-open');
            timer = setTimeout(() => { panel.hidden = true; }, 220);
        }
    };
    button.addEventListener('click', () => setOpen(button.getAttribute('aria-expanded') !== 'true'));
    document.addEventListener('click', (event) => {
        if (!root.contains(event.target) && button.getAttribute('aria-expanded') === 'true') setOpen(false);
    });
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && button.getAttribute('aria-expanded') === 'true') {
            const restoreFocus = root.contains(document.activeElement);
            if (restoreFocus) button.focus();
            setOpen(false);
        }
    });
    root.addEventListener('focusout', () => {
        setTimeout(() => {
            if (!root.contains(document.activeElement) && button.getAttribute('aria-expanded') === 'true') setOpen(false);
        }, 0);
    });
})();

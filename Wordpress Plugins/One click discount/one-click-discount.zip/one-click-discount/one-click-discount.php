<?php
/**
 * Plugin Name: تخفیف یک‌کلیکی ووکامرس
 * Description: اعمال یا حذف تخفیف روی همه محصولات، یک دسته‌بندی، یا محصولات و تنوع‌های انتخابی با یک کلیک.
 * Version: 1.2.0
 * Author: امیرحسین حسین‌مردی
 * Author URI: https://www.linkedin.com/in/amirhossein-hosseinmardi
 * Requires Plugins: woocommerce
 * Text Domain: one-click-discount
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class OCD_Plugin {
	const META = '_ocd_applied';

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'menu' ] );
		add_action( 'wp_ajax_ocd_products', [ $this, 'ajax_products' ] );
		add_action( 'admin_post_ocd_apply', [ $this, 'handle_apply' ] );
		add_action( 'admin_post_ocd_remove', [ $this, 'handle_remove' ] );
	}

	public function menu() {
		add_submenu_page( 'woocommerce', 'تخفیف یک‌کلیکی', 'تخفیف یک‌کلیکی', 'manage_woocommerce', 'one-click-discount', [ $this, 'page' ] );
	}

	public function page() {
		if ( ! class_exists( 'WooCommerce' ) ) { echo '<div class="notice notice-error"><p>ووکامرس فعال نیست.</p></div>'; return; }
		$cats = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false ] );
		if ( isset( $_GET['ocd_done'] ) ) {
			printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html( sprintf( '%d محصول به‌روزرسانی شد.', (int) $_GET['ocd_done'] ) ) );
		}
		$nonce = wp_create_nonce( 'ocd' );
		?>
		<div class="wrap" dir="rtl">
			<h1>تخفیف یک‌کلیکی</h1>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ocd-form">
				<?php wp_nonce_field( 'ocd' ); ?>
				<table class="form-table">
					<tr><th>محدوده</th><td>
						<label><input type="radio" name="scope" value="all" checked> همه محصولات فروشگاه</label><br>
						<label><input type="radio" name="scope" value="cats"> دسته‌بندی خاص</label>
						<div id="ocd-cat-box" style="display:none;margin:8px 0 0">
							<select name="cats[]" id="ocd-cats" multiple size="8" style="min-width:300px">
								<?php foreach ( $cats as $c ) printf( '<option value="%d">%s</option>', $c->term_id, esc_html( $c->name ) ); ?>
							</select>
							<p class="description">برای انتخاب چند مورد Ctrl را نگه دارید.</p>
							<p>
								<label><input type="radio" name="mode" value="all" checked> همه محصولات این دسته‌بندی‌ها</label><br>
								<label><input type="radio" name="mode" value="some"> انتخاب محصولات و تنوع‌های خاص</label>
							</p>
							<div id="ocd-products" style="display:none;max-height:350px;overflow:auto;border:1px solid #ccd0d4;background:#fff;padding:8px;max-width:600px"></div>
						</div>
					</td></tr>
					<tr><th>نوع تخفیف</th><td>
						<select name="type"><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت</option></select>
					</td></tr>
					<tr><th>مقدار</th><td><input type="number" name="value" step="any" min="0" required></td></tr>
					<tr><th>شروع (اختیاری)</th><td><input type="date" name="from"></td></tr>
					<tr><th>پایان (اختیاری)</th><td><input type="date" name="to"></td></tr>
				</table>
				<button type="submit" name="action" value="ocd_apply" class="button button-primary" onclick="return confirm('تخفیف اعمال شود؟');">اعمال تخفیف</button>
				<button type="submit" name="action" value="ocd_remove" class="button" formnovalidate onclick="return confirm('تخفیف‌های اعمال‌شده با این افزونه در محدوده انتخابی حذف شوند؟');">حذف تخفیف (در همین محدوده)</button>
			</form>
			<p style="margin-top:30px;color:#666">ساخته‌شده توسط <a href="https://www.linkedin.com/in/amirhossein-hosseinmardi" target="_blank" rel="noopener">امیرحسین حسین‌مردی</a></p>
		</div>
		<script>
		(function(){
			var f=document.getElementById('ocd-form'),box=document.getElementById('ocd-cat-box'),
			cats=document.getElementById('ocd-cats'),list=document.getElementById('ocd-products');
			function val(n){var e=f.querySelector('input[name='+n+']:checked');return e?e.value:'';}
			function sync(){
				box.style.display=val('scope')==='cats'?'block':'none';
				var show=(val('scope')==='cats'&&val('mode')==='some');
				list.style.display=show?'block':'none';
				if(show)load();
			}
			function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
			function load(){
				var ids=[].map.call(cats.selectedOptions,function(o){return o.value;});
				if(!ids.length){list.innerHTML='<em>ابتدا دسته‌بندی انتخاب کنید.</em>';return;}
				list.innerHTML='در حال بارگذاری...';
				var u=ajaxurl+'?action=ocd_products&_wpnonce=<?php echo $nonce; ?>&cats='+ids.join(',');
				fetch(u,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){
					if(!d.length){list.innerHTML='<em>محصولی یافت نشد.</em>';return;}
					var h='<label><strong><input type="checkbox" id="ocd-all"> انتخاب همه</strong></label><hr>';
					d.forEach(function(p){
						if(p.vars.length){
							h+='<div style="margin:6px 0"><label><strong><input type="checkbox" class="ocd-parent"> '+esc(p.name)+'</strong></label>';
							p.vars.forEach(function(v){
								h+='<label style="display:block;margin-right:24px"><input type="checkbox" class="ocd-var" name="variation_ids[]" value="'+v.id+'"> '+esc(v.name)+'</label>';
							});
							h+='</div>';
						}else{
							h+='<label style="display:block;margin:4px 0"><input type="checkbox" name="product_ids[]" value="'+p.id+'"> '+esc(p.name)+'</label>';
						}
					});
					list.innerHTML=h;
					document.getElementById('ocd-all').onchange=function(){
						var c=this.checked;
						[].forEach.call(list.querySelectorAll('input[type=checkbox]'),function(i){if(i.id!=='ocd-all')i.checked=c;});
					};
					[].forEach.call(list.querySelectorAll('.ocd-parent'),function(pc){
						pc.onchange=function(){
							var c=pc.checked;
							[].forEach.call(pc.closest('div').querySelectorAll('.ocd-var'),function(i){i.checked=c;});
						};
					});
				}).catch(function(){list.innerHTML='<em>خطا در بارگذاری لیست.</em>';});
			}
			f.addEventListener('change',function(e){
				if(e.target===cats||e.target.name==='scope'||e.target.name==='mode')sync();
			});
			sync();
		})();
		</script>
		<?php
	}

	public function ajax_products() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json( [] );
		check_ajax_referer( 'ocd' );
		$slugs = [];
		foreach ( array_filter( array_map( 'intval', explode( ',', $_GET['cats'] ?? '' ) ) ) as $id ) {
			$t = get_term( $id, 'product_cat' );
			if ( $t && ! is_wp_error( $t ) ) $slugs[] = $t->slug;
		}
		if ( ! $slugs ) wp_send_json( [] );
		$out = [];
		$products = wc_get_products( [ 'limit' => -1, 'category' => $slugs, 'status' => [ 'publish', 'private', 'draft' ], 'orderby' => 'title', 'order' => 'ASC' ] );
		foreach ( $products as $p ) {
			$item = [ 'id' => $p->get_id(), 'name' => $p->get_name(), 'vars' => [] ];
			if ( $p->is_type( 'variable' ) ) {
				foreach ( $p->get_children() as $vid ) {
					$v = wc_get_product( $vid );
					if ( ! $v ) continue;
					$attr  = wc_get_formatted_variation( $v, true, false );
					$price = wp_strip_all_tags( html_entity_decode( wc_price( $v->get_regular_price() ) ) );
					$item['vars'][] = [ 'id' => $vid, 'name' => ( $attr ?: '#' . $vid ) . ' — ' . $price ];
				}
			}
			$out[] = $item;
		}
		wp_send_json( $out );
	}

	private function selected_vars() {
		return array_values( array_filter( array_map( 'intval', (array) ( $_POST['variation_ids'] ?? [] ) ) ) );
	}

	private function is_some_mode() {
		return ( $_POST['scope'] ?? 'all' ) === 'cats' && ( $_POST['mode'] ?? 'all' ) === 'some';
	}

	private function get_ids() {
		$status = [ 'publish', 'private', 'draft' ];
		if ( ( $_POST['scope'] ?? 'all' ) !== 'cats' ) {
			return wc_get_products( [ 'limit' => -1, 'return' => 'ids', 'status' => $status ] );
		}
		if ( $this->is_some_mode() ) {
			$ids = array_map( 'intval', (array) ( $_POST['product_ids'] ?? [] ) );
			foreach ( $this->selected_vars() as $vid ) {
				$parent = wp_get_post_parent_id( $vid );
				if ( $parent ) $ids[] = $parent;
			}
			return array_values( array_unique( array_filter( $ids ) ) );
		}
		$slugs = [];
		foreach ( array_map( 'intval', (array) ( $_POST['cats'] ?? [] ) ) as $id ) {
			$t = get_term( $id, 'product_cat' );
			if ( $t && ! is_wp_error( $t ) ) $slugs[] = $t->slug;
		}
		if ( ! $slugs ) return [];
		return wc_get_products( [ 'limit' => -1, 'return' => 'ids', 'category' => $slugs, 'status' => $status ] );
	}

	private function targets( $p ) {
		if ( ! $p->is_type( 'variable' ) ) return [ $p ];
		$children = $p->get_children();
		if ( $this->is_some_mode() ) {
			$children = array_intersect( $children, $this->selected_vars() );
		}
		return array_filter( array_map( 'wc_get_product', $children ) );
	}

	private function guard() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'دسترسی ندارید.' );
		check_admin_referer( 'ocd' );
	}

	private function done( $n ) {
		wp_safe_redirect( add_query_arg( [ 'page' => 'one-click-discount', 'ocd_done' => $n ], admin_url( 'admin.php' ) ) );
		exit;
	}

	private function calc( $regular, $type, $value ) {
		$regular = (float) $regular;
		if ( $regular <= 0 ) return '';
		$sale = $type === 'percent' ? $regular * ( 1 - min( $value, 100 ) / 100 ) : $regular - $value;
		if ( $sale <= 0 ) return '';
		return wc_format_decimal( round( $sale, wc_get_price_decimals() ) );
	}

	public function handle_apply() {
		$this->guard();
		$type  = ( $_POST['type'] ?? '' ) === 'fixed' ? 'fixed' : 'percent';
		$value = (float) ( $_POST['value'] ?? 0 );
		if ( $value <= 0 ) wp_die( 'مقدار تخفیف نامعتبر است.' );
		$from = sanitize_text_field( $_POST['from'] ?? '' );
		$to   = sanitize_text_field( $_POST['to'] ?? '' );
		@set_time_limit( 0 );

		$count = 0;
		foreach ( $this->get_ids() as $id ) {
			$p = wc_get_product( $id );
			if ( ! $p ) continue;
			foreach ( $this->targets( $p ) as $t ) {
				$sale = $this->calc( $t->get_regular_price(), $type, $value );
				if ( $sale === '' ) continue;
				$t->set_sale_price( $sale );
				$t->set_date_on_sale_from( $from ?: null );
				$t->set_date_on_sale_to( $to ?: null );
				$t->update_meta_data( self::META, 1 );
				$t->save();
			}
			if ( $p->is_type( 'variable' ) ) WC_Product_Variable::sync( $id );
			$count++;
		}
		$this->done( $count );
	}

	public function handle_remove() {
		$this->guard();
		@set_time_limit( 0 );
		$count = 0;
		foreach ( $this->get_ids() as $id ) {
			$p = wc_get_product( $id );
			if ( ! $p ) continue;
			foreach ( $this->targets( $p ) as $t ) {
				if ( ! $t->get_meta( self::META ) ) continue;
				$t->set_sale_price( '' );
				$t->set_date_on_sale_from( null );
				$t->set_date_on_sale_to( null );
				$t->delete_meta_data( self::META );
				$t->save();
			}
			if ( $p->is_type( 'variable' ) ) WC_Product_Variable::sync( $id );
			$count++;
		}
		$this->done( $count );
	}
}
new OCD_Plugin();
